import React from 'react'
import '../App.scss';

function Header() {
  return (
    <div className='header'>
      <div className='inn'>
        <h1 className='logo'>
          <img src='./Yjin.png'></img>
        </h1>
        <ul className='gnb'>
          <li>
            <a>
              <span>01</span>
              <p>main</p>
            </a>
          </li>
          <li>
            <a>
              <span>02</span>
              <p>Intro</p>
            </a>
          </li>
          <li>
            <a>
              <span>03</span>
              <p>Work</p>
            </a>
          </li>
          <li>
            <a>
              <span>04</span>
              <p>Contact</p>
            </a>
          </li>
        </ul>
      </div>
    </div>
  )
}

export default Header