import React, { useContext, useEffect, useReducer, useRef, useState } from "react";
import '../App.scss';
import { myContext } from "./Context";


function Home() {
  const {src, setSrc, data, setData, testNum} = useContext(myContext);
  const [scrollPosition, setScrollPosition] = useState(0);
  const mainSectionRef = useRef(null);

 // Function to handle scroll event and update scroll position state
 const handleScroll = () => {
  const position = window.scrollY;
  setScrollPosition(position);
};

// Update scroll position on scroll event
useEffect(() => {
  window.addEventListener('scroll', handleScroll);
  return () => {
    window.removeEventListener('scroll', handleScroll);
  };
}, []);


useEffect(() => {
  const observer = new IntersectionObserver(
    (entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          window.addEventListener('scroll', handleScroll);
        } else {
          window.removeEventListener('scroll', handleScroll);
        }
      });
    },
    { threshold: 0.5 } // Adjust threshold as needed
  );

  observer.observe(mainSectionRef.current);

  return () => {
    observer.unobserve(mainSectionRef.current);
  };
}, []);


const helloOffset = scrollPosition * -2;


  const works = [
    {id: 1, name: "LionHill", desc:"어쩌구 저쩌구", img:"./facilites_logo.png", siteHref: "", gitHref: "",  vHref: ""},
    {id: 2, name: "장 보는 날", desc:"어쩌구 저쩌구", img:"/mainlogo.png", siteHref: "", gitHref: "",  vHref: ""},
    {id: 3, name: "3분을 버텨라", desc:"어쩌구 저쩌구", img:"./world_earth.png", siteHref: "", gitHref: "",  vHref: ""},
    {id: 4, name: "Selecto Coffee", desc:"어쩌구 저쩌구", img:"./selec_logo.png", siteHref: "", gitHref: "",  vHref: ""},
    {id: 5, name: "Andar", desc:"어쩌구 저쩌구", img:"./facilites_logo.png", siteHref: "",  gitHref: "",  vHref: ""},
    {id: 6, name: "Naver", desc:"어쩌구 저쩌구", img:"/mainlogo.png", siteHref: "", gitHref: "",  vHref: ""},
    {id: 7, name: "Kakao Mobility", desc:"어쩌구 저쩌구", img:"./world_earth.png", siteHref: "", gitHref: "",  vHref: ""},
    {id: 8, name: "서울시청", desc:"어쩌구 저쩌구", img:"./selec_logo.png", siteHref: "", gitHref: "",  vHref: ""}
  ]

  
  function thumbMove(e){    
    let pos = {y:e.clientY, x:e.clientX}
    

    const thumb = document.querySelector('.thumb');
    thumb.style=`left:${pos.x -100}px; top:${pos.y-100}px;display:block;`;
  }
  
  useEffect(()=>{
    const list = document.querySelector('.list');
    const li = document.querySelectorAll('.list li');

    li.forEach(ele=>{
      ele.addEventListener('mousemove',thumbMove);
      ele.addEventListener('mouseover',thumbMove);
    })
    list.addEventListener('mouseleave',()=>{
      document.querySelector('.thumb').style="display:none"
    })

    const contactSection = document.querySelector('.contact');
    contactSection.addEventListener('mouseenter', () => {
      document.querySelector('.thumb').style.display = 'none';
    });

    const twoBoxSections = document.querySelectorAll('.two_box');
  // 모든 'two_box' 섹션에 대해 이벤트 리스너를 추가합니다.
  twoBoxSections.forEach((box) => {
    box.addEventListener('mouseenter', () => {
      setSrc(''); // 이미지를 숨기려면 src를 빈 문자열 또는 null로 설정합니다.
    });
});


  }, [])




  return (
    <div className="wrap">
      <section className="main"  ref={mainSectionRef}>
      <strong className="point" style={{ marginLeft: `${helloOffset}px` }}>HELLO</strong>
        <div className="move-bg">
          <div className="txt">
            <p>Front-end</p>
            <p> Devel<span><img src="./o.png"></img></span>per</p>
            <p className="eart">PORTFOLI@2023</p>
           
          </div>
        </div>
      </section>
      <section className="intro">
      <strong className="point">INTRO</strong>
        <p>
      무너지지않는 끈기를 가진 개발을 좋아하는 신입 웹프론트엔드 김유진입니다. <br />
              적극적인 의사소통 (강조) 을 바탕으로 회사와 같이 성장하겠습니다! <br />
      Figma 부터 SQL 까지 (강조) 모든 지식을 겸비한 프론트엔드 김유진 (강조) 입니다.
        </p>
      </section>
      <section className="project">
        <div className="move-bg">
          <h2>PROJECT</h2>
          <figure>
            <img src={src} class="thumb"></img>
          </figure>
          {

          works.map(item=>(
            <ul onMouseOver={()=>{setSrc(item.img)}} className="list" >
            <li data-num={item.id}>
              <a>
                <div className="one_box">
                  <strong className="title">{item.name}</strong>
                  <p>
                    {item.desc}
                  </p>
                </div>
                {/* <figure>
                  <img src={item.img}></img>
                </figure> */}
                <div className="two_box">
                  <a href="">
                    site view
                    <img src="./arrow.png" className="arow" alt=""></img>
                    </a>
                  <div className="icon">
                  <a href="">
                    <span className="link">
                      <img src="./github.png" alt="" className="hub"></img>
                      <img src="./velog.png" alt="" className="log"></img>
                    </span>
                  </a>
                  </div>
                </div>
              </a>
            </li>
          </ul>
          ))

          }
        </div>
      </section>
      <section className="contact">
        <div className="area">
          <div className="tit">
          <a href="mailto:dbwls9610@navr.com">LET's talk</a>
          </div>

          <div className="cont_wrap">
           <div className="card">
              <div className="front"></div>
              <div className="back"></div>
           </div>


            <div className="link">
            <p>CONTANT ME!</p>
            <span className="wrap">
            <a href=""><img src="./github.png" alt=""></img></a>
            <a href=""><img src="./velog.png" alt=""></img></a>
            </span>
            </div>
            </div>
        </div>
        <div className="tag">
          <div className="move">
          <span>FUBLSHER &nbsp;&nbsp;&nbsp; 감각 &nbsp;&nbsp;&nbsp; SCSS &nbsp;&nbsp;&nbsp; HTML &nbsp;&nbsp;&nbsp; jQury &nbsp;&nbsp;&nbsp; NEXT.JS &nbsp;&nbsp;&nbsp; MONGODB &nbsp;&nbsp;&nbsp;
          </span>
          <span>FUBLSHER &nbsp;&nbsp;&nbsp; 감각 &nbsp;&nbsp;&nbsp; SCSS &nbsp;&nbsp;&nbsp; HTML &nbsp;&nbsp;&nbsp; jQury &nbsp;&nbsp;&nbsp; NEXT.JS &nbsp;&nbsp;&nbsp; MONGODB &nbsp;&nbsp;&nbsp;
          </span>
          <span>FUBLSHER &nbsp;&nbsp;&nbsp; 감각 &nbsp;&nbsp;&nbsp; SCSS &nbsp;&nbsp;&nbsp; HTML &nbsp;&nbsp;&nbsp; jQury &nbsp;&nbsp;&nbsp; NEXT.JS &nbsp;&nbsp;&nbsp; MONGODB &nbsp;&nbsp;&nbsp;
          </span>
          <span>FUBLSHER &nbsp;&nbsp;&nbsp; 감각 &nbsp;&nbsp;&nbsp; SCSS &nbsp;&nbsp;&nbsp; HTML &nbsp;&nbsp;&nbsp; jQury &nbsp;&nbsp;&nbsp; NEXT.JS &nbsp;&nbsp;&nbsp; MONGODB &nbsp;&nbsp;&nbsp;
          </span>
         </div>
         <div className="move2">
          <span className="maq-02">react.js&nbsp;&nbsp;&nbsp; Javascript &nbsp;&nbsp;&nbsp; 웹접근성 &nbsp;&nbsp;&nbsp; NEXT.JS &nbsp;&nbsp;&nbsp; Github
          &nbsp;&nbsp;&nbsp;책임감 &nbsp;&nbsp;&nbsp; Steady &nbsp;&nbsp;&nbsp; 협업
          </span>
          </div>
        </div>
      </section>
    </div>
  );
}

export default Home;
